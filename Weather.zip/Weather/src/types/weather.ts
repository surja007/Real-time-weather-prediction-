export interface Coordinates {
  lat: number;
  lon: number;
}

export interface CurrentWeatherData {
  temperature: number;
  feelsLike: number;
  highTemp: number;
  lowTemp: number;
  humidity: number;
  pressure: number;
  windSpeed: number;
  windDirection: string;
  condition: string;
  uvIndex: number;
  visibility: number;
  sunrise: string;
  sunset: string;
  lastUpdated: string;
}

export interface ForecastData {
  date: string;
  condition: string;
  highTemp: number;
  lowTemp: number;
  precipitation: number;
  humidity: number;
  windSpeed: number;
}

export interface WeatherAlert {
  title: string;
  description: string;
  severity: string;
  effective: string;
  expires: string;
  source: string;
}

export interface WeatherData {
  location: string;
  coordinates: Coordinates;
  current: CurrentWeatherData;
  forecast: ForecastData[];
  alerts: WeatherAlert[];
}