import { WeatherData } from '../types/weather';

// This is a mock service that returns fake data
// In a real app, this would make API calls to a weather service

export async function getWeatherData(location: string): Promise<WeatherData> {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Generate mock data based on the location
  return {
    location,
    coordinates: {
      lat: 40.7128, // New York coordinates as example
      lon: -74.0060
    },
    current: {
      temperature: 22,
      feelsLike: 24,
      highTemp: 26,
      lowTemp: 18,
      humidity: 65,
      pressure: 1012,
      windSpeed: 12,
      windDirection: 'NW',
      condition: 'Partly Cloudy',
      uvIndex: 6,
      visibility: 10,
      sunrise: '06:43 AM',
      sunset: '07:32 PM',
      lastUpdated: new Date().toLocaleTimeString()
    },
    forecast: [
      {
        date: new Date().toISOString(),
        condition: 'Partly Cloudy',
        highTemp: 26,
        lowTemp: 18,
        precipitation: 10,
        humidity: 65,
        windSpeed: 12
      },
      {
        date: new Date(Date.now() + 86400000).toISOString(), // + 1 day
        condition: 'Sunny',
        highTemp: 28,
        lowTemp: 19,
        precipitation: 0,
        humidity: 55,
        windSpeed: 10
      },
      {
        date: new Date(Date.now() + 172800000).toISOString(), // + 2 days
        condition: 'Sunny',
        highTemp: 29,
        lowTemp: 20,
        precipitation: 0,
        humidity: 50,
        windSpeed: 8
      },
      {
        date: new Date(Date.now() + 259200000).toISOString(), // + 3 days
        condition: 'Cloudy',
        highTemp: 25,
        lowTemp: 19,
        precipitation: 20,
        humidity: 70,
        windSpeed: 15
      },
      {
        date: new Date(Date.now() + 345600000).toISOString(), // + 4 days
        condition: 'Rain',
        highTemp: 22,
        lowTemp: 17,
        precipitation: 80,
        humidity: 85,
        windSpeed: 20
      },
      {
        date: new Date(Date.now() + 432000000).toISOString(), // + 5 days
        condition: 'Cloudy',
        highTemp: 23,
        lowTemp: 16,
        precipitation: 30,
        humidity: 75,
        windSpeed: 12
      },
      {
        date: new Date(Date.now() + 518400000).toISOString(), // + 6 days
        condition: 'Partly Cloudy',
        highTemp: 24,
        lowTemp: 18,
        precipitation: 10,
        humidity: 60,
        windSpeed: 10
      },
    ],
    alerts: location.toLowerCase().includes('new york') ? [
      {
        title: 'Heat Advisory',
        description: 'A heat advisory is in effect until 8 PM today. Heat index values up to 105 expected.',
        severity: 'Moderate',
        effective: 'June 15, 2025 12:00 PM',
        expires: 'June 15, 2025 8:00 PM',
        source: 'National Weather Service'
      }
    ] : []
  };
}