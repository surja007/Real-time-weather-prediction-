import React from 'react';
import { AlertTriangle, Info } from 'lucide-react';
import { WeatherAlert } from '../types/weather';

interface WeatherAlertsProps {
  alerts: WeatherAlert[];
}

const WeatherAlerts: React.FC<WeatherAlertsProps> = ({ alerts }) => {
  if (!alerts || alerts.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden transition-colors duration-300">
        <div className="p-6">
          <div className="flex items-center justify-center">
            <Info size={24} className="text-blue-500 mr-2" />
            <p className="text-gray-600 dark:text-gray-300">No weather alerts at this time.</p>
          </div>
        </div>
      </div>
    );
  }

  const getSeverityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'severe':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      case 'moderate':
        return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300';
      case 'minor':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      default:
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden transition-colors duration-300">
      <div className="p-6">
        <div className="space-y-4">
          {alerts.map((alert, index) => (
            <div key={index} className={`p-4 rounded-lg ${getSeverityColor(alert.severity)}`}>
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <AlertTriangle className="h-5 w-5" />
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium">{alert.title}</h3>
                  <div className="mt-2 text-sm">
                    <p>{alert.description}</p>
                  </div>
                  <div className="mt-2">
                    <div className="-mx-2 -my-1 flex flex-wrap">
                      <div className="px-2 py-1 text-xs font-medium">
                        Effective: {alert.effective}
                      </div>
                      <div className="px-2 py-1 text-xs font-medium">
                        Expires: {alert.expires}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default WeatherAlerts;