import React, { useState, useEffect } from 'react';
import CurrentWeather from './CurrentWeather';
import WeatherForecast from './WeatherForecast';
import WeatherMap from './WeatherMap';
import HistoricalData from './HistoricalData';
import WeatherAlerts from './WeatherAlerts';
import { getWeatherData } from '../services/weatherService';
import { WeatherData } from '../types/weather';

interface DashboardProps {
  location: string;
}

const Dashboard: React.FC<DashboardProps> = ({ location }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);
        const data = await getWeatherData(location);
        setWeatherData(data);
      } catch (err) {
        setError('Failed to load weather data. Please try again later.');
        console.error('Error fetching weather data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [location]);

  if (loading) {
    return (
      <div className="flex justify-center items-center flex-grow">
        <div className="animate-pulse flex flex-col items-center">
          <div className="h-32 w-32 bg-blue-200 dark:bg-blue-700 rounded-full mb-4"></div>
          <div className="h-4 w-48 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
          <div className="h-4 w-36 bg-gray-200 dark:bg-gray-700 rounded"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center flex-grow">
        <div className="bg-red-100 dark:bg-red-900 border border-red-400 dark:border-red-700 text-red-700 dark:text-red-300 px-4 py-3 rounded relative" role="alert">
          <strong className="font-bold">Error: </strong>
          <span className="block sm:inline">{error}</span>
        </div>
      </div>
    );
  }

  if (!weatherData) {
    return (
      <div className="flex justify-center items-center flex-grow">
        <div className="bg-yellow-100 dark:bg-yellow-900 border border-yellow-400 dark:border-yellow-700 text-yellow-700 dark:text-yellow-300 px-4 py-3 rounded relative" role="alert">
          <strong className="font-bold">Notice: </strong>
          <span className="block sm:inline">No weather data available for this location.</span>
        </div>
      </div>
    );
  }

  return (
    <main className="flex-grow container mx-auto px-4 py-6">
      <section className="mb-8" id="dashboard">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-4">
          Current Weather in {weatherData.location}
        </h2>
        <CurrentWeather data={weatherData.current} />
      </section>

      <section className="mb-8" id="forecast">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-4">
          7-Day Forecast
        </h2>
        <WeatherForecast forecast={weatherData.forecast} />
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-4">
          Weather Map
        </h2>
        <WeatherMap location={weatherData.location} coordinates={weatherData.coordinates} />
      </section>

      <section className="mb-8" id="alerts">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-4">
          Weather Alerts
        </h2>
        <WeatherAlerts alerts={weatherData.alerts} />
      </section>

      <section className="mb-8" id="historical">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-4">
          Historical Weather
        </h2>
        <HistoricalData location={weatherData.location} />
      </section>
    </main>
  );
};

export default Dashboard;