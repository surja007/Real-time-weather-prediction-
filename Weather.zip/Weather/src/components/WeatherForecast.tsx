import React from 'react';
import { ForecastData } from '../types/weather';
import { getWeatherIcon } from '../utils/weatherIcons';

interface WeatherForecastProps {
  forecast: ForecastData[];
}

const WeatherForecast: React.FC<WeatherForecastProps> = ({ forecast }) => {
  // Helper function to format the day name
  const formatDay = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { weekday: 'short' });
  };

  return (
    <div className="overflow-x-auto">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-4 min-w-max sm:min-w-0">
        {forecast.map((day, index) => {
          const WeatherIcon = getWeatherIcon(day.condition);
          
          return (
            <div 
              key={index} 
              className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 flex flex-col items-center transition-transform duration-300 hover:scale-105"
            >
              <h3 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">
                {index === 0 ? 'Today' : formatDay(day.date)}
              </h3>
              <div className="my-2">
                <WeatherIcon className="h-12 w-12 text-blue-500 dark:text-blue-400" />
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                {day.condition}
              </p>
              <div className="flex items-center justify-center space-x-2 mt-1">
                <span className="text-lg font-bold text-gray-900 dark:text-white">{day.highTemp}°</span>
                <span className="text-sm text-gray-500 dark:text-gray-400">{day.lowTemp}°</span>
              </div>
              <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-700 w-full text-center">
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  <span className="inline-block mr-2">💧 {day.precipitation}%</span>
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default WeatherForecast;