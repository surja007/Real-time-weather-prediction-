import React from 'react';
import { Coordinates } from '../types/weather';

interface WeatherMapProps {
  location: string;
  coordinates: Coordinates;
}

const WeatherMap: React.FC<WeatherMapProps> = ({ location, coordinates }) => {
  // This would normally be an interactive map using a library like Leaflet or Google Maps
  // For this example, we'll use a placeholder with styling
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden transition-colors duration-300">
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">
            {location} Weather Map
          </h3>
          <div className="flex space-x-2">
            <button className="px-3 py-1 bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300 rounded-md text-sm hover:bg-blue-200 dark:hover:bg-blue-800 transition-colors">
              Temperature
            </button>
            <button className="px-3 py-1 bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300 rounded-md text-sm hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
              Precipitation
            </button>
            <button className="px-3 py-1 bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300 rounded-md text-sm hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
              Wind
            </button>
          </div>
        </div>
        
        <div 
          className="h-80 bg-blue-50 dark:bg-gray-700 rounded-lg flex items-center justify-center relative overflow-hidden"
          style={{
            backgroundImage: `url('https://images.pexels.com/photos/3888585/pexels-photo-3888585.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        >
          <div className="absolute inset-0 bg-black opacity-20 dark:opacity-50"></div>
          <div className="relative z-10 text-center p-4 bg-white bg-opacity-80 dark:bg-gray-800 dark:bg-opacity-80 rounded-lg shadow-lg">
            <p className="text-gray-800 dark:text-gray-200">
              Interactive weather map would be displayed here
            </p>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
              Coordinates: {coordinates.lat.toFixed(4)}, {coordinates.lon.toFixed(4)}
            </p>
          </div>
        </div>
        
        <div className="flex justify-between items-center mt-4">
          <div className="text-xs text-gray-500 dark:text-gray-400">
            Data source: Weather Service API
          </div>
          <div className="text-xs text-gray-500 dark:text-gray-400">
            Last updated: 10 minutes ago
          </div>
        </div>
      </div>
    </div>
  );
};

export default WeatherMap;