import React from 'react';
import { Thermometer, Droplets, Wind, Sunrise, Sunset, Gauge } from 'lucide-react';
import { CurrentWeatherData } from '../types/weather';
import { getWeatherIcon } from '../utils/weatherIcons';

interface CurrentWeatherProps {
  data: CurrentWeatherData;
}

const CurrentWeather: React.FC<CurrentWeatherProps> = ({ data }) => {
  const WeatherIcon = getWeatherIcon(data.condition);
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden transition-colors duration-300">
      <div className="p-6">
        <div className="flex flex-col md:flex-row items-center md:items-start">
          <div className="flex-shrink-0 flex flex-col items-center mb-4 md:mb-0 md:mr-8">
            <div className="text-6xl mb-2">
              <WeatherIcon className="h-24 w-24 text-blue-500 dark:text-blue-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-200">{data.condition}</h3>
          </div>
          
          <div className="flex-grow text-center md:text-left">
            <div className="text-5xl font-bold text-gray-900 dark:text-white mb-2">
              {data.temperature}°
            </div>
            <div className="text-lg text-gray-600 dark:text-gray-300 mb-4">
              Feels like {data.feelsLike}°
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-4">
              <div className="flex items-center">
                <Thermometer size={20} className="text-red-500 mr-2" />
                <div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">High/Low</div>
                  <div className="font-medium text-gray-800 dark:text-gray-200">{data.highTemp}° / {data.lowTemp}°</div>
                </div>
              </div>
              
              <div className="flex items-center">
                <Droplets size={20} className="text-blue-500 mr-2" />
                <div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Humidity</div>
                  <div className="font-medium text-gray-800 dark:text-gray-200">{data.humidity}%</div>
                </div>
              </div>
              
              <div className="flex items-center">
                <Gauge size={20} className="text-purple-500 mr-2" />
                <div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Pressure</div>
                  <div className="font-medium text-gray-800 dark:text-gray-200">{data.pressure} hPa</div>
                </div>
              </div>
              
              <div className="flex items-center">
                <Wind size={20} className="text-teal-500 mr-2" />
                <div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Wind</div>
                  <div className="font-medium text-gray-800 dark:text-gray-200">{data.windSpeed} km/h</div>
                </div>
              </div>
              
              <div className="flex items-center">
                <Sunrise size={20} className="text-orange-500 mr-2" />
                <div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Sunrise</div>
                  <div className="font-medium text-gray-800 dark:text-gray-200">{data.sunrise}</div>
                </div>
              </div>
              
              <div className="flex items-center">
                <Sunset size={20} className="text-orange-500 mr-2" />
                <div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Sunset</div>
                  <div className="font-medium text-gray-800 dark:text-gray-200">{data.sunset}</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
          <p className="text-gray-600 dark:text-gray-300">
            Last updated: {data.lastUpdated}
          </p>
        </div>
      </div>
    </div>
  );
};

export default CurrentWeather;