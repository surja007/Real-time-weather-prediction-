import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from './charts/SimpleChart';

interface HistoricalDataProps {
  location: string;
}

const HistoricalData: React.FC<HistoricalDataProps> = ({ location }) => {
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'year'>('week');

  // Mock data for the chart - in a real app, this would come from the API
  const generateMockData = () => {
    const data = [];
    let startDate = new Date();
    let numPoints = 7;
    
    if (timeRange === 'month') {
      numPoints = 30;
    } else if (timeRange === 'year') {
      numPoints = 12;
    }
    
    for (let i = 0; i < numPoints; i++) {
      const date = new Date(startDate);
      date.setDate(startDate.getDate() - (numPoints - i));
      
      const formattedDate = timeRange === 'year' 
        ? date.toLocaleDateString('en-US', { month: 'short' })
        : date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      
      data.push({
        name: formattedDate,
        temperature: Math.round(15 + Math.random() * 15),
        humidity: Math.round(40 + Math.random() * 40)
      });
    }
    
    return data;
  };

  const data = generateMockData();

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden transition-colors duration-300">
      <div className="p-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2 sm:mb-0">
            Historical Weather Data for {location}
          </h3>
          
          <div className="inline-flex rounded-md shadow-sm">
            <button
              type="button"
              onClick={() => setTimeRange('week')}
              className={`px-4 py-2 text-sm font-medium rounded-l-md ${
                timeRange === 'week'
                ? 'bg-blue-600 text-white hover:bg-blue-700'
                : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600'
              } border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:z-10`}
            >
              Week
            </button>
            <button
              type="button"
              onClick={() => setTimeRange('month')}
              className={`px-4 py-2 text-sm font-medium ${
                timeRange === 'month'
                ? 'bg-blue-600 text-white hover:bg-blue-700'
                : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600'
              } border-t border-b border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:z-10`}
            >
              Month
            </button>
            <button
              type="button"
              onClick={() => setTimeRange('year')}
              className={`px-4 py-2 text-sm font-medium rounded-r-md ${
                timeRange === 'year'
                ? 'bg-blue-600 text-white hover:bg-blue-700'
                : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600'
              } border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:z-10`}
            >
              Year
            </button>
          </div>
        </div>
        
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data}
              margin={{
                top: 5,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis yAxisId="left" orientation="left" stroke="#0ea5e9" />
              <YAxis yAxisId="right" orientation="right" stroke="#8884d8" />
              <Tooltip />
              <Legend />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="temperature"
                stroke="#0ea5e9"
                activeDot={{ r: 8 }}
                name="Temperature (°C)"
              />
              <Line yAxisId="right" type="monotone" dataKey="humidity" stroke="#8884d8" name="Humidity (%)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
        
        <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
          <div className="flex justify-between">
            <div className="text-sm">
              <span className="text-gray-500 dark:text-gray-400">Avg Temp: </span>
              <span className="font-medium text-gray-800 dark:text-gray-200">
                {Math.round(data.reduce((acc, curr) => acc + curr.temperature, 0) / data.length)}°C
              </span>
            </div>
            <div className="text-sm">
              <span className="text-gray-500 dark:text-gray-400">Avg Humidity: </span>
              <span className="font-medium text-gray-800 dark:text-gray-200">
                {Math.round(data.reduce((acc, curr) => acc + curr.humidity, 0) / data.length)}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HistoricalData;