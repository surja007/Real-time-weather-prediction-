import React from 'react';
import { Sun, Cloud, CloudRain, CloudSnow, CloudLightning, Wind, CloudFog } from 'lucide-react';

type WeatherIconType = React.FC<React.SVGProps<SVGSVGElement>>;

export function getWeatherIcon(condition: string): WeatherIconType {
  const conditionLower = condition.toLowerCase();
  
  if (conditionLower.includes('clear') || conditionLower.includes('sunny')) {
    return Sun;
  } else if (conditionLower.includes('rain') || conditionLower.includes('shower') || conditionLower.includes('drizzle')) {
    return CloudRain;
  } else if (conditionLower.includes('snow') || conditionLower.includes('sleet') || conditionLower.includes('ice')) {
    return CloudSnow;
  } else if (conditionLower.includes('thunder') || conditionLower.includes('lightning') || conditionLower.includes('storm')) {
    return CloudLightning;
  } else if (conditionLower.includes('fog') || conditionLower.includes('mist') || conditionLower.includes('haze')) {
    return CloudFog;
  } else if (conditionLower.includes('wind') || conditionLower.includes('gust')) {
    return Wind;
  } else {
    // Default to cloudy for everything else
    return Cloud;
  }
}