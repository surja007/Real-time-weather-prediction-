import React, { useState } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Footer from './components/Footer';

function App() {
  const [location, setLocation] = useState('New York');

  return (
    <ThemeProvider>
      <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
        <Header setLocation={setLocation} />
        <Dashboard location={location} />
        <Footer />
      </div>
    </ThemeProvider>
  );
}

export default App;